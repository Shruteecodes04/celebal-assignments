
import streamlit as st
import pandas as pd
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import openai

st.set_page_config(page_title="Loan Q&A Chatbot", layout="centered")

@st.cache_resource
def load_data():
    df = pd.read_csv("Training Dataset.csv")
    documents = []
    for i, row in df.iterrows():
        doc = f"Loan_ID: {row['Loan_ID']}, Gender: {row['Gender']}, Married: {row['Married']}, ApplicantIncome: {row['ApplicantIncome']}, Loan_Status: {row['Loan_Status']}"
        documents.append(doc)
    return df, documents

@st.cache_resource
def setup_model_and_index(docs):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    embeddings = model.encode(docs)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(np.array(embeddings))
    return model, index, embeddings

def retrieve(query, model, index, docs, k=3):
    query_vec = model.encode([query])
    D, I = index.search(np.array(query_vec), k)
    return [docs[i] for i in I[0]]

def generate_answer(query, context_docs):
    openai.api_key = st.secrets["OPENAI_API_KEY"]
    context = "\n".join(context_docs)
    prompt = f"Answer the following question based on the data:\nContext:\n{context}\n\nQuestion: {query}"
    response = openai.ChatCompletion.create(
        model='gpt-3.5-turbo',
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ]
    )
    return response['choices'][0]['message']['content']

st.title("📊 Loan Eligibility Q&A Chatbot")
st.write("Ask questions about the loan dataset using AI.")

query = st.text_input("❓ Enter your question:")

df, docs = load_data()
model, index, _ = setup_model_and_index(docs)

if query:
    with st.spinner("Retrieving answer..."):
        context_docs = retrieve(query, model, index, docs)
        try:
            answer = generate_answer(query, context_docs)
            st.markdown("### ✅ Answer:")
            st.success(answer)
        except Exception as e:
            st.error(f"Error: {e}")
